﻿
namespace Soundboard_Software_V1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label portNameLabel;
            this.portNameComboBox = new System.Windows.Forms.ComboBox();
            this.errortext = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.btn1Path = new System.Windows.Forms.Label();
            this.btn2Path = new System.Windows.Forms.Label();
            this.btn3Path = new System.Windows.Forms.Label();
            this.btn4Path = new System.Windows.Forms.Label();
            this.btn5Path = new System.Windows.Forms.Label();
            this.btn10Path = new System.Windows.Forms.Label();
            this.btn9Path = new System.Windows.Forms.Label();
            this.btn8Path = new System.Windows.Forms.Label();
            this.btn7Path = new System.Windows.Forms.Label();
            this.btn6Path = new System.Windows.Forms.Label();
            this.refresh = new System.Windows.Forms.Button();
            portNameLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // portNameLabel
            // 
            portNameLabel.AutoSize = true;
            portNameLabel.Location = new System.Drawing.Point(27, 16);
            portNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            portNameLabel.Name = "portNameLabel";
            portNameLabel.Size = new System.Drawing.Size(79, 17);
            portNameLabel.TabIndex = 9;
            portNameLabel.Text = "Port Name:";
            // 
            // portNameComboBox
            // 
            this.portNameComboBox.FormattingEnabled = true;
            this.portNameComboBox.Location = new System.Drawing.Point(117, 13);
            this.portNameComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.portNameComboBox.Name = "portNameComboBox";
            this.portNameComboBox.Size = new System.Drawing.Size(160, 24);
            this.portNameComboBox.TabIndex = 10;
            // 
            // errortext
            // 
            this.errortext.AutoSize = true;
            this.errortext.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errortext.ForeColor = System.Drawing.Color.Red;
            this.errortext.Location = new System.Drawing.Point(26, 48);
            this.errortext.Name = "errortext";
            this.errortext.Size = new System.Drawing.Size(0, 24);
            this.errortext.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(30, 87);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Button 1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(321, 87);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(91, 23);
            this.button4.TabIndex = 17;
            this.button4.Text = "Button 4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(127, 87);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 23);
            this.button2.TabIndex = 19;
            this.button2.Text = "Button 2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(224, 87);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(91, 23);
            this.button3.TabIndex = 18;
            this.button3.Text = "Button 3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(418, 87);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(91, 23);
            this.button5.TabIndex = 23;
            this.button5.Text = "Button 5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(30, 123);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(91, 23);
            this.button6.TabIndex = 22;
            this.button6.Text = "Button 6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(127, 123);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(91, 23);
            this.button7.TabIndex = 21;
            this.button7.Text = "Button 7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(224, 123);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(91, 23);
            this.button8.TabIndex = 20;
            this.button8.Text = "Button 8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(418, 123);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(91, 23);
            this.button10.TabIndex = 25;
            this.button10.Text = "Button 10";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(321, 123);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(91, 23);
            this.button9.TabIndex = 24;
            this.button9.Text = "Button 9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // btn1Path
            // 
            this.btn1Path.AutoSize = true;
            this.btn1Path.Location = new System.Drawing.Point(561, 31);
            this.btn1Path.Name = "btn1Path";
            this.btn1Path.Size = new System.Drawing.Size(65, 17);
            this.btn1Path.TabIndex = 26;
            this.btn1Path.Text = "Button 1:";
            // 
            // btn2Path
            // 
            this.btn2Path.AutoSize = true;
            this.btn2Path.Location = new System.Drawing.Point(561, 48);
            this.btn2Path.Name = "btn2Path";
            this.btn2Path.Size = new System.Drawing.Size(65, 17);
            this.btn2Path.TabIndex = 27;
            this.btn2Path.Text = "Button 2:";
            // 
            // btn3Path
            // 
            this.btn3Path.AutoSize = true;
            this.btn3Path.Location = new System.Drawing.Point(561, 65);
            this.btn3Path.Name = "btn3Path";
            this.btn3Path.Size = new System.Drawing.Size(65, 17);
            this.btn3Path.TabIndex = 28;
            this.btn3Path.Text = "Button 3:";
            // 
            // btn4Path
            // 
            this.btn4Path.AutoSize = true;
            this.btn4Path.Location = new System.Drawing.Point(561, 82);
            this.btn4Path.Name = "btn4Path";
            this.btn4Path.Size = new System.Drawing.Size(65, 17);
            this.btn4Path.TabIndex = 29;
            this.btn4Path.Text = "Button 4:";
            // 
            // btn5Path
            // 
            this.btn5Path.AutoSize = true;
            this.btn5Path.Location = new System.Drawing.Point(561, 100);
            this.btn5Path.Name = "btn5Path";
            this.btn5Path.Size = new System.Drawing.Size(65, 17);
            this.btn5Path.TabIndex = 30;
            this.btn5Path.Text = "Button 5:";
            // 
            // btn10Path
            // 
            this.btn10Path.AutoSize = true;
            this.btn10Path.Location = new System.Drawing.Point(553, 185);
            this.btn10Path.Name = "btn10Path";
            this.btn10Path.Size = new System.Drawing.Size(73, 17);
            this.btn10Path.TabIndex = 35;
            this.btn10Path.Text = "Button 10:";
            // 
            // btn9Path
            // 
            this.btn9Path.AutoSize = true;
            this.btn9Path.Location = new System.Drawing.Point(561, 168);
            this.btn9Path.Name = "btn9Path";
            this.btn9Path.Size = new System.Drawing.Size(65, 17);
            this.btn9Path.TabIndex = 34;
            this.btn9Path.Text = "Button 9:";
            // 
            // btn8Path
            // 
            this.btn8Path.AutoSize = true;
            this.btn8Path.Location = new System.Drawing.Point(561, 151);
            this.btn8Path.Name = "btn8Path";
            this.btn8Path.Size = new System.Drawing.Size(65, 17);
            this.btn8Path.TabIndex = 33;
            this.btn8Path.Text = "Button 8:";
            // 
            // btn7Path
            // 
            this.btn7Path.AutoSize = true;
            this.btn7Path.Location = new System.Drawing.Point(561, 134);
            this.btn7Path.Name = "btn7Path";
            this.btn7Path.Size = new System.Drawing.Size(65, 17);
            this.btn7Path.TabIndex = 32;
            this.btn7Path.Text = "Button 7:";
            // 
            // btn6Path
            // 
            this.btn6Path.AutoSize = true;
            this.btn6Path.Location = new System.Drawing.Point(561, 117);
            this.btn6Path.Name = "btn6Path";
            this.btn6Path.Size = new System.Drawing.Size(65, 17);
            this.btn6Path.TabIndex = 31;
            this.btn6Path.Text = "Button 6:";
            // 
            // refresh
            // 
            this.refresh.Location = new System.Drawing.Point(300, 13);
            this.refresh.Name = "refresh";
            this.refresh.Size = new System.Drawing.Size(71, 24);
            this.refresh.TabIndex = 36;
            this.refresh.Text = "Refresh";
            this.refresh.UseVisualStyleBackColor = true;
            this.refresh.Click += new System.EventHandler(this.button9_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(855, 204);
            this.Controls.Add(this.refresh);
            this.Controls.Add(this.btn10Path);
            this.Controls.Add(this.btn9Path);
            this.Controls.Add(this.btn8Path);
            this.Controls.Add(this.btn7Path);
            this.Controls.Add(this.btn6Path);
            this.Controls.Add(this.btn5Path);
            this.Controls.Add(this.btn4Path);
            this.Controls.Add(this.btn3Path);
            this.Controls.Add(this.btn2Path);
            this.Controls.Add(this.btn1Path);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.errortext);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.portNameComboBox);
            this.Controls.Add(portNameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox portNameComboBox;
        private System.Windows.Forms.Label errortext;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer timer1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label btn1Path;
        private System.Windows.Forms.Label btn2Path;
        private System.Windows.Forms.Label btn3Path;
        private System.Windows.Forms.Label btn4Path;
        private System.Windows.Forms.Label btn5Path;
        private System.Windows.Forms.Label btn10Path;
        private System.Windows.Forms.Label btn9Path;
        private System.Windows.Forms.Label btn8Path;
        private System.Windows.Forms.Label btn7Path;
        private System.Windows.Forms.Label btn6Path;
        private System.Windows.Forms.Button refresh;
    }
}

