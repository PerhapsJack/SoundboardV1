﻿using SerialPortListener.Serial;
using System;
using System.IO.Ports;
using System.Threading;
using System.Windows.Forms;


namespace Soundboard_Software_V1
{


    
    public partial class Form1 : Form
    {

        SerialPortManager _spManager;
      

        string filename1;
        string filename2;
        string filename3;
        string filename4;
        string filename5;
        string filename6;
        string filename7;
        string filename8;
        string filename9;
        string filename10;
        string selected;
        string data;
        bool go;
        public Form1()
        {
            _spManager = new SerialPortManager();
            SerialSettings mySerialSettings = _spManager.CurrentSerialSettings;

            InitializeComponent();

            portNameComboBox.DataSource = mySerialSettings.PortNameCollection;
        }

        public void serialConnect()
        {
            serialPort1.Close();
            serialPort1.Dispose();
            string cum = selected;
            if (go == false)
            {
               
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog1 = new OpenFileDialog();

            openfiledialog1.Filter = "wav files (*.wav)|*.wav";
            openfiledialog1.FilterIndex = 1;
            openfiledialog1.RestoreDirectory = true;
            openfiledialog1.ShowDialog();
            filename1 = openfiledialog1.FileName;
            btn1Path.Text = "Button 1: " + openfiledialog1.SafeFileName;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog2 = new OpenFileDialog();

            openfiledialog2.Filter = "wav files (*.wav)|*.wav";
            openfiledialog2.FilterIndex = 2;
            openfiledialog2.RestoreDirectory = true;
            openfiledialog2.ShowDialog();
            filename2 = openfiledialog2.FileName;
            btn2Path.Text = "Button 2: " + openfiledialog2.SafeFileName;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog3 = new OpenFileDialog();

            openfiledialog3.Filter = "wav files (*.wav)|*.wav";
            openfiledialog3.FilterIndex = 3;
            openfiledialog3.RestoreDirectory = true;
            openfiledialog3.ShowDialog();
            filename3 = openfiledialog3.FileName;
            btn3Path.Text = "Button 3: " + openfiledialog3.SafeFileName;
        }
        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog4 = new OpenFileDialog();

            openfiledialog4.Filter = "wav files (*.wav)|*.wav";
            openfiledialog4.FilterIndex = 4;
            openfiledialog4.RestoreDirectory = true;
            openfiledialog4.ShowDialog();
            filename4 = openfiledialog4.FileName;
            btn4Path.Text = "Button 4: " + openfiledialog4.SafeFileName;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog5 = new OpenFileDialog();

            openfiledialog5.Filter = "wav files (*.wav)|*.wav";
            openfiledialog5.FilterIndex = 5;
            openfiledialog5.RestoreDirectory = true;
            openfiledialog5.ShowDialog();
            filename5 = openfiledialog5.FileName;
            btn5Path.Text = "Button 5: " + openfiledialog5.SafeFileName;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog6 = new OpenFileDialog();

            openfiledialog6.Filter = "wav files (*.wav)|*.wav";
            openfiledialog6.FilterIndex = 6;
            openfiledialog6.RestoreDirectory = true;
            openfiledialog6.ShowDialog();
            filename6 = openfiledialog6.FileName;
            btn6Path.Text = "Button 6: " + openfiledialog6.SafeFileName;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog7 = new OpenFileDialog();

            openfiledialog7.Filter = "wav files (*.wav)|*.wav";
            openfiledialog7.FilterIndex = 7;
            openfiledialog7.RestoreDirectory = true;
            openfiledialog7.ShowDialog();
            filename7 = openfiledialog7.FileName;
            btn7Path.Text = "Button 7: " + openfiledialog7.SafeFileName;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog8 = new OpenFileDialog();

            openfiledialog8.Filter = "wav files (*.wav)|*.wav";
            openfiledialog8.FilterIndex = 8;
            openfiledialog8.RestoreDirectory = true;
            openfiledialog8.ShowDialog();
            filename8 = openfiledialog8.FileName;
            btn8Path.Text = "Button 8: " + openfiledialog8.SafeFileName;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog9 = new OpenFileDialog();

            openfiledialog9.Filter = "wav files (*.wav)|*.wav";
            openfiledialog9.FilterIndex = 9;
            openfiledialog9.RestoreDirectory = true;
            openfiledialog9.ShowDialog();
            filename9 = openfiledialog9.FileName;
            btn9Path.Text = "Button 9: " + openfiledialog9.SafeFileName;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfiledialog10 = new OpenFileDialog();

            openfiledialog10.Filter = "wav files (*.wav)|*.wav";
            openfiledialog10.FilterIndex = 10;
            openfiledialog10.RestoreDirectory = true;
            openfiledialog10.ShowDialog();
            filename10 = openfiledialog10.FileName;
            btn10Path.Text = "Button 10: " + openfiledialog10.SafeFileName;
        }
        private void Form1_Load(object sender, EventArgs e)
        { }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {
                string line = serialPort1.ReadLine();
                this.BeginInvoke(new LineReceivedEvent(LineReceived), line);
            }
            catch(System.IO.IOException)
            { }
            
        }

        private delegate void LineReceivedEvent(string line);

        public void LineReceived(string line)
        {
            int var;
            data = line;
            Int32.TryParse(line, out var);
            if (var == 1)
            {
                if (String.IsNullOrEmpty(filename1))
                {
                    errortext.Text = "Buttton 1 MUST have a file attached";
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer(filename1);
                    player.Play();
                    errortext.Text = "";
                }
            }
            else if (var == 2)
            {
                if (String.IsNullOrEmpty(filename2))
                {
                    errortext.Text = "Buttton 2 MUST have a file attached";
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer(filename2);
                    player.Play();
                    errortext.Text = "";
                }
            }
            else if (var == 3)
            {
                if (String.IsNullOrEmpty(filename3))
                {
                    errortext.Text = "Buttton 3 MUST have a file attached";
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer(filename3);
                    player.Play();
                    errortext.Text = "";
                }
            }
            else if (var == 4)
            {
                if (String.IsNullOrEmpty(filename4))
                {
                    errortext.Text = "Buttton 4 MUST have a file attached";
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer(filename4);
                    player.Play();
                    errortext.Text = "";
                }
            }
            else if (var == 5)
            {
                if (String.IsNullOrEmpty(filename5))
                {
                    errortext.Text = "Buttton 5 MUST have a file attached";
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer(filename5);
                    player.Play();
                    errortext.Text = "";
                }
            }
            else if (var == 6)
            {
                if (String.IsNullOrEmpty(filename6))
                {
                    errortext.Text = "Buttton 6 MUST have a file attached";
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer(filename6);
                    player.Play();
                    errortext.Text = "";
                }
            }
            else if (var == 7)
            {
                if (String.IsNullOrEmpty(filename7))
                {
                    errortext.Text = "Buttton 7 MUST have a file attached";
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer(filename7);
                    player.Play();
                    errortext.Text = "";
                }
            }
            else if (var == 8)
            {
                if (String.IsNullOrEmpty(filename8))
                {
                    errortext.Text = "Buttton 8 MUST have a file attached";
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer(filename8);
                    player.Play();
                    errortext.Text = "";
                }
            }
            else if (var == 9)
            {
                if (String.IsNullOrEmpty(filename9))
                {
                    errortext.Text = "Buttton 9 MUST have a file attached";
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer(filename9);
                    player.Play();
                    errortext.Text = "";
                }
            }
            else if (var == 10)
            {
                if (String.IsNullOrEmpty(filename10))
                {
                    errortext.Text = "Buttton 10 MUST have a file attached";
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer(filename10);
                    player.Play();
                    errortext.Text = "";
                }
            }
            else
            {
                errortext.Text = "FATAL DEVICE FIRMWARE ERROR - CONTACT SUPPORT";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            _spManager = new SerialPortManager();
            SerialSettings mySerialSettings = _spManager.CurrentSerialSettings;




            selected = this.portNameComboBox.GetItemText(this.portNameComboBox.SelectedItem);

            go = String.IsNullOrEmpty(selected);



            if (serialPort1.IsOpen == false && go == false)
            {
                serialPort1.PortName = selected;
                serialPort1.BaudRate = 9600;
                serialPort1.DataReceived += serialPort1_DataReceived;
                try
                {
                    serialPort1.Open();
                    errortext.Text = "";
                }
                catch (System.IO.IOException)
                {
                    portNameComboBox.DataSource = null;
                    portNameComboBox.Items.Clear();
                    errortext.Text = "FATAL ERROR - No Device Connected";
                }

            }
        }

        private void refresh_Click(object sender, EventArgs e)
        {
            _spManager = new SerialPortManager();
            SerialSettings mySerialSettings = _spManager.CurrentSerialSettings;

            portNameComboBox.DataSource = mySerialSettings.PortNameCollection;
        }

      

       
    }
}

